connect sys/sys as sysdba
CREATE USER Meet_midterm_Q4 IDENTIFIED BY 6118 ;
GRANT connect, resource TO Meet_midterm_Q4 ;